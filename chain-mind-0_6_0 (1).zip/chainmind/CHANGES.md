# Chain Mind 0.6.0 (unreleased)

**Works on ten assistants instead of four:** ChatGPT, Claude, Gemini, Microsoft Copilot, Grok, Perplexity, DeepSeek, Qwen, Mistral Le Chat and Meta AI. Everything in 0.2.0–0.5.0 (gauge, handoff, firewall, DLP, risk score, drift, copy cleaner, pre-send guard, search) now applies to all of them.

- **Six new providers** (`providers.js`) — hosts: `copilot.microsoft.com`, `copilot.cloud.microsoft`, `www.perplexity.ai`, `chat.deepseek.com`, `chat.qwen.ai`, `chat.mistral.ai`, `www.meta.ai` (and the bare `perplexity.ai` / `meta.ai`). The manifest asks for access to exactly these sites, no more.
- **Three-tier DOM reader** (`adapters.js`) — the new assistants have no stable response format Chain Mind could parse (Copilot uses a WebSocket), so each reads the page: selectors for that site first, then role attributes many chat UIs share, then class-name guesses. A redesign that breaks the first tier drops to the next instead of reading nothing. `chainmind.inspect()` in the page console reports which tier is in use, the role split, and which composer was found.
- **Reply detection everywhere** (`hook.js`) — any streaming POST on a supported site now signals "reply finished" so the page is re-read right after it. Bodies are only kept for endpoints the hook already knew. GET streams are ignored, and the bridge stops waiting after two minutes, so a stream that never closes cannot freeze rescans.
- **Conversation ids** (`bridge-core.js`) — Perplexity (title slugs) and Copilot (opaque ids) have no UUID in the URL; the path now identifies the chat instead of everything collapsing into "new".
- **Send detection** (`guards.js`) — the pre-send guard also recognises send buttons named by `id`, `title` or `type=submit` (Qwen, Perplexity). Pressing Enter is held on every site regardless.
- **Composer fallback** — if a site's own composer selector stops matching, any textbox on the page is tried, so "put the handoff in the message box" and "remind the AI of my goal" keep working.
- Catalog, recommender and link-lookalike list know the six new assistants. The recommender says when a window size is an estimate.
- `build.js` now fails if `manifest.json` and `providers.js` disagree about hosts, so adding a site cannot half-work.
- Popup recognises every supported site (it used to match a hard-coded list of four).

## Fixed in 0.6.0 (found by testing every button)

1. **"Ask this chat instead" (and every "put text in the message box" button) could fail silently.** The write used `execCommand`, which does nothing when the page is not focused — the state it is in while the popup is open — yet the code still reported success. New `lib/composer.js` tries four methods in turn (execCommand, paste event, beforeinput, direct text), reads the box back to confirm the text landed, appends to a draft instead of wiping it, and if the box refuses, puts the text on the clipboard and says so. The popup now distinguishes "tab not connected, reload it", "no message box found" and "copied instead".
2. **Carrying a conversation from the popup crashed.** `compress.js` used `countText` and `compactExtractive` without importing them. That only worked inside the flattened content bundle, so the popup's carry-to buttons threw a ReferenceError. Imports added; a scan of every module for undefined names is now clean.
3. **Policy tab: "Reset to defaults" brought back the rule you had just added.** `getPolicy()` returned the shared default array, which Add rule then edited. It now returns a copy.
4. **"Open popup" from the in-page panel did nothing on Chrome builds that refuse `openPopup`.** It now opens the dashboard instead.
5. **Redact and send** now waits until the redacted text is actually in the box, and sends nothing if it could not be written.

Tested end to end in a simulated browser on all ten assistants (reading, gauge, firewall, Ask this chat, handoff prompt, carry-to, export, no errors): 90 checks. Also the popup (exports, import and insert, settings, dashboard links), the in-page panel (every button), the pre-send guard, copy cleaner, background worker (tabs, badge, quota), and every dashboard tab and tool. All pass. This is a simulation, not the real sites: real editors can still behave differently, which is why a failed insert now falls back to the clipboard.

## Not verified

- **The selectors for the six new sites were written from how those apps are built, not run against the live sites.** The test below uses markup I wrote in that shape, so it shows the logic works, not that each site matches. If one reads wrong, run `chainmind.inspect()` on it; `tier: classes` or `messages: 0` means it needs a hand-written entry in `adapters.js` (a few lines per site).
- **Context windows for the six are estimates (128k each)** and are labelled as such in the recommender. Check them against each vendor's plan page before trusting the gauge.
- Upload counts are shown for ChatGPT, Claude, Gemini and Grok only; the six new sites show "this session".
- Copilot for Microsoft 365 (`m365.cloud.microsoft`), Grok on x.com, and other regional or enterprise addresses are not included. Adding one is a hosts entry plus a manifest line.

## Test

A simulated browser loaded the built bundle on all ten hosts with representative markup: each read 2 messages with the right roles, the class-name fallback worked with no site selectors at all, and an unsupported host stayed inert. The stream hook was exercised separately (POST stream signalled without keeping the body, GET stream ignored, known endpoints unchanged).

# Chain Mind 0.5.0 (unreleased)

- **Dynamic AI risk scoring** (`risk.js`) — every conversation gets four sub-scores (prompt injection, sensitive exposure, malicious code, untrusted content) and an overall score, recomputed as the chat grows: 0–25 Low, 26–50 Moderate, 51–75 High, 76–100 Critical. Severe findings add up; medium and low ones are capped per category, so noise tops out at High. Recent findings weigh more, repeats weigh less, and anything the firewall blocked sets a floor of 60. Heuristic triage, not a calibrated probability. Shown in the in-page panel, the popup, and a new dashboard Risk tab with history.
- **Context drift detection** (`drift.js`) — compares recent messages with the opening goal (word-overlap similarity), tracks rules you set ("don't use X", "must use Y") and flags when the assistant breaks one or stops reflecting it, finds conflicting decisions ("use A for the database" then "use B"), and lists earlier points that have dropped out of recent messages. A toast appears once per new problem. "Remind the AI of my goal" puts a ready-made reminder in the message box. New dashboard Drift tab. Works on words, not meaning: a chat that moves on deliberately will read as drift.
- Analytics now scores a drift test set (five short conversations, written by me).

# Chain Mind 0.4.0 (unreleased)

Builds on the 0.3.0 security suite. Every item is local; nothing is sent anywhere.

- **Pre-send interception** (`content/guards.js`, `scanDraft` in `firewall.js`) — Enter or the send button is held when the draft contains secrets, high-entropy strings, or hidden text. Choices: *Redact and send*, *Redact only*, *Send anyway*, *Cancel*. Each choice is logged. Email/phone alone never hold a draft. Switch off under Settings.
- **Hidden-text detection** (`hidden.js`) — invisible Unicode tag characters (decoded to the hidden message), zero-width runs, bidi controls, HTML comments, invisible-styled spans, alt/title text (scanned for injection), mixed-script words.
- **Encoding tricks** (`encoding.js`) — base64, ROT13 and homoglyph/invisible-character obfuscation, re-checked with the injection detector.
- **Link reputation** (`links.js`) — lookalike domains, brand-as-subdomain, punycode, raw IPs, user-info URLs, and image URLs that carry data out.
- **Dependency check** (`deps.js`) — typosquats of popular npm/pip packages, installs from URLs, custom indexes. It cannot tell whether an unfamiliar name exists on a registry; that needs a lookup.
- **Entropy-based secrets** (`entropy.js`) — random-looking strings; ignores URLs, hex hashes and plain identifiers.
- **Handoff sanitizer** (`sanitize.js`, `handoff.js`) — redacts secrets, strips hidden characters, and prefixes a notice if the transcript contains AI-directed instructions.
- **Smart compression** (`compress.js`) — when a chat does not fit, builds goal / decisions / constraints / open items / latest code / recent messages instead of head-and-tail. Extractive: selects existing sentences, does not rewrite them.
- **Semantic diff** — the dashboard's Handoff tab shows what did not make the trip (code blocks, key statements, coverage %). Keyword-overlap heuristic.
- **Cross-provider search** (`archive.js`, Search tab) — off by default; saves redacted conversations locally.
- **Copy sanitizer** (`sanitize.js`) — selected text copied from a chat loses invisible characters, odd spaces, citation markers, and stray markdown (`**`, `*`, `#`, `* ` bullets). Code blocks keep their content. Joiners are kept in emoji and Indic scripts. It does **not** remove statistical watermarks (those live in word choice), and does not intercept a site's own Copy button.
- Dashboard: Search, Handoff and Settings tabs; Analytics now scores seven detectors. The test sets are small and were written alongside the detectors, so their perfect scores show the rules work on those cases, not how they perform on real traffic.

# Chain Mind 0.3.0 (unreleased)

A security suite added on top of 0.2.0's context transfer: an AI firewall that
scans every message flowing through a supported tab, a least-privilege policy
engine for actions an assistant describes taking, a code scanner, and a
dashboard to see all of it. Drop this folder over your existing one and run
`node build.js` — the bundle in this drop is already built, so it loads
unpacked as-is too.

## New in 0.3.0 — Security suite

Twelve pieces, all local: nothing here calls out to a server, and the event
log lives in `chrome.storage.local` like everything else Chain Mind keeps.

1. **AI Context Transfer** — already existed in 0.2.0 (`schema.js`'s
   `compactExtractive()` and the handoff-brief prompt); unchanged here.
2. **AI Firewall** (`src/lib/security/firewall.js`) — the layer every message
   passes through. Runs injection detection, secret detection, and (on
   assistant replies) code scanning and agent-action monitoring, then folds
   the results into one verdict: `allow`, `flag`, `require_approval`, `block`.
   Wired into `bridge-core.js`'s `ingest()`, so it runs automatically as a
   conversation is read — no separate step.
3. **Prompt Injection Detection** (`injection.js`) — direct-override patterns
   ("ignore all previous instructions", DAN-style jailbreaks) scored high
   regardless of where they came from, and indirect markers (an instruction
   addressed to "the AI" sitting inside content) scored critical specifically
   when the text did not come from the user typing it — a scraped page, a
   tool result — since that is the case the user never saw.
4. **AI Data Loss Prevention** (`dlp.js`) — pattern rules for AWS/GitHub/
   Slack/Stripe keys, private-key blocks, JWTs, DB connection strings,
   passwords, SSNs, card numbers (Luhn-checked), emails, and phone numbers.
   `redact()` returns a copy with matches swapped for `[REDACTED:KIND]`.
5. **AI Agent Security** (`agentMonitor.js`) — reads an assistant's reply for
   the shapes an action takes once written down (a shell fence, `fetch`/
   `curl`, a file write, a SQL statement) and runs each one past the policy.
   Text-pattern extraction from the transcript, not a live tool-call hook —
   Chain Mind only ever sees what a chat page renders.
6. **Least-Privilege Policy Engine** (`policy.js`) — ordered `ALLOW` /
   `BLOCK` / `REQUIRE_APPROVAL` rules, first match wins. Ships with a
   conservative default (recursive deletes and `curl | sh` blocked outright;
   shell, writes, network, and DB actions need approval by default; reads are
   allowed). Editable from the dashboard's Policy tab; stored under
   `policyRules` so edits survive a reload.
7. **AI Code Security Scanner** (`codeScanner.js`) — regex rules for SQL
   built by concatenation, `innerHTML` XSS, shell command injection, SSRF
   from unvalidated input, hardcoded credentials, weak hashes, `eval`/`exec`,
   insecure RNG for tokens, disabled TLS verification, and path traversal.
   Each finding carries an OWASP Top 10 category and a CWE id.
8. **Context Integrity** (`contextIntegrity.js`) — classifies a message as
   trusted (user-typed or the model's own reply), sensitive (pulled from a
   page/PDF/tool result), or untrusted (pulled in *and* carrying an
   injection marker).
9. **Originality & Integrity Analyzer** (`originality.js`) — shingled n-gram
   overlap against text you paste in for comparison (not a web-wide check —
   this extension has no crawler), plus pattern flags for claims that read as
   authoritative with no citation nearby ("studies show", "experts agree").
   Framed throughout as a rewriting aid, not a plagiarism verdict.
10. **AI Output Cleaner** (`cleaner.js`) — strips filler openers ("Certainly!",
    "As an AI language model"), a short list of stock phrases, and sentences
    repeated verbatim later in the same reply. Leaves fenced code blocks
    untouched.
11. **AI Security Dashboard** (`src/ui/dashboard.html`, opened from the popup
    or the in-page firewall summary) — an Overview tab with live counts, risk
    levels by severity, findings by detector, and an attack-chain view for the
    most recent conversation with anything flagged; a full Events log with a
    type filter; the Policy editor; and a Tools tab exposing the DLP
    redactor, originality analyzer, and output cleaner as standalone paste-in
    utilities.
12. **Research & Analytics** (`analytics.js`, Analytics tab) — an
    eight-case hand-labeled test set for injection detection and a six-case
    set for DLP, scored for precision/recall/F1/latency against the live
    detectors so the numbers are checkable in the source rather than
    asserted. Separately, live detection rate and counts pulled from actual
    events logged in this browser.

None of the detectors above are exhaustive — they are regex and heuristics,
not a model. They are written to fail toward showing you something rather
than staying silent, which means the honest cost is more false positives, not
fewer. The Analytics tab exists so that trade-off is visible rather than
assumed.

## New in 0.2.0

**`src/lib/quota.js`** — the quota banner, persisted. `readNotice()` was already
finding "limit reached, resets at 3pm" and then throwing it away when the tab
closed. Now it parses a reset time out of it and keeps two small records per
provider, `quota:{id}` and `avail:{id}`, both overwritten rather than appended.

**`src/lib/recommend.js`** — two offline recommenders.
`rankProviders()` answers "where do I go now", scoring each other assistant on
quota state, usable window against the size of the thread you are carrying, how
full your open chat there already is, and content fit. `suggestTools()` answers
"what tool does this job" against the catalog.

**`src/lib/catalog.js`** — the tool list, restructured into tags with a
`checked` date per entry. Entries seeded from your list carry `checked: null`
and the UI labels them unverified, because a directory that implies it was
checked and was not is worse than a short one. Miners and view-selling services
from the seed list are left out on purpose.

**HUD routing block** — hidden until the gauge goes critical or the site prints
a quota banner, then it lists up to three places to go with one line of
reasoning each. The button trims to half the target's window, copies, and opens
the tab.

**Popup advisor** — a box you describe a job into. Local match first; when
nothing fits closely it says so and offers to put the question to the assistant
in the tab instead, which costs one turn and no API key.

## Fixed

1. **A thin scrape could overwrite a full parse.** `ingest()` compared
   `conv.id`, but `makeConversation()` mints a fresh UUID when the caller has no
   id, and `scrape()` never passes one — so the ids never matched, the guard
   never fired, and a mid-render DOM read could replace a complete network
   parse. Now keyed on the conversation URL, which both paths agree on.
2. **Upload count reset on reload and over-counted.** It lived in a plain
   variable, and matched `/upload|\/files\b/` against every request, so
   ChatGPT's file *listing* GETs counted as uploads. Now persisted per
   conversation, POST-only, deduped by URL.
3. **Storage would eventually stop accepting writes.** Full conversations, 50 of
   them, into a 10 MB bucket. Added `unlimitedStorage`.
4. **Cleanup almost never ran.** `chrome.runtime.onStartup` fires on browser
   launch only. Moved to a `chrome.alarms` sweep every three hours, which also
   drops expired quota records.
5. **Rescans fought the stream.** The MutationObserver fired continuously while
   a reply was being written. The hook now emits `stream-start`, and the
   observer sits out until the stream ends.

## Matching bugs found while testing the advisor

Worth knowing about, because they are the shape of bug this kind of feature has:

- "look up a value across sheets" returned **Looka**, and "a blog post that
  ranks on google" returned **Fronty** — short query words were allowed to
  substring-match product names. Name matching now needs five characters.
- "debug my python script" returned three tools that merely carry a `code` tag
  and buried the right answer, which is the assistant already in front of you.
  General assistants are out of the catalog search now and handled by the
  weak-match path.
- "wedding seating chart" scored a dashboard tool as a strong match, because
  `chart` expanded to two tags. It maps to one now and lands as weak.

`SYNONYMS` in `catalog.js` is where this quality lives. Every search that should
have worked and did not is one line there.

## Still worth doing

- Verify the catalog links and fill in `checked` dates. Until then most of the
  list shows as unverified, which is accurate but not a good look at 40 entries.
- The reset-time parser handles clock times and relative durations in English
  only. Anyone using these sites in another language gets `blocking: true` with
  no reset time, which degrades correctly but is not great.
- `carryTo()` copies the trimmed transcript. Copying the *handoff brief* instead,
  once one exists in the thread, would be strictly better — that needs the brief
  captured as a first-class artifact, which is the next feature.
